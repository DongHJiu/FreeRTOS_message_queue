#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED_Data_A1(int i);
void LED_Data_A2(int i);
void LED_Data_A3(int i);
void LED_Data_A4(int i);

#endif
